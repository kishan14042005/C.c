package StringOperationPackage;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
@Path("generic")
public class StringOperations {

    @Context
    private UriInfo context;

    public StringOperations() {
    }
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getHtml() {
        throw new UnsupportedOperationException();
    }
   
     @PUT
    @Consumes(MediaType.TEXT_HTML)
    public void putHtml(String content) {
        
    }
    
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    @Path("/Uppercase")
    public String toUppercaseMethod(String str)
    {
       return str.toUpperCase(); 
    }
     @PUT
    @Consumes(MediaType.TEXT_HTML)
    @Path("/Lowercase")
    public String toLowerCaseMethod(String str)
    {
        return str.toLowerCase();
    }
}
