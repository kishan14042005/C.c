/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaclientws;

/**
 *
 * @author kc140
 */
public class JavaClientWS {
    
  

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Resultado:"+ hello("Maria Alves"));
    }

    private static String hello(java.lang.String name) {
        webservices.HelloWorld_Service service = new webservices.HelloWorld_Service();
        webservices.HelloWorld port = service.getHelloWorldPort();
        return port.hello(name);
    }
    
}
